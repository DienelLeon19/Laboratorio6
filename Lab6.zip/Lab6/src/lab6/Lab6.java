    package lab6;

public class Lab6 
{

    public static void main(String[] args)
    {
        GestorCursos Ref = new GestorCursos();
        Ref.setLocationRelativeTo(Ref);
        Ref.setVisible(true); 
        Ref.esconder();
        
    }
    
}
